import React, { useState } from 'react'
import './FormInput.css';
const FormInput=(props)=>{
  const [focused,setFocus]=useState(false);
  const {label, errorMessage,onChange,id,...inputProps}=props;
  const handlefocus=(e)=>{
    setFocus(true);
  }
  return<div className='formInput'>
    <form>
      <label>{label}</label>
      <input {...inputProps} onChange={onChange} onBlur={handlefocus} onFocus={()=>inputProps.name==="confirmPassword" && setFocus(true)} focused={focused.toString()}/>
      <span>{errorMessage}</span>
      </form>

  </div>
}
export default FormInput